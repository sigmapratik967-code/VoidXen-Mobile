# VoidXen Mobile — Full Android Launcher

This is a real Android **source project**, not an HTML mockup.

Included:
- Portrait phone-first launcher
- Home / Play
- S1 server only
- S1 address: 188.127.241.74:1618
- Character Selection (3 editable character images)
- Spawn Point screen
- Settings
- Server Rules
- Discord Support
- Editable launcher background and logo
- AndroidManifest, Gradle files, resources and Java source

## Important: class.dex
`classes.dex` is **not normally stored in an Android Studio source project**. Android Gradle generates `classes.dex` automatically when the project is compiled and packages it inside the APK.

So after building:
`app/build/outputs/apk/debug/app-debug.apk`
will contain the generated `classes.dex`.

## Phone build
If you already have Gradle 8.2 on your phone:
1. Extract this ZIP.
2. Open the project folder in your terminal.
3. Run:
   `~/gradle-8.2/bin/gradle :app:assembleDebug`
4. APK:
   `app/build/outputs/apk/debug/app-debug.apk`

If Android SDK/Build Tools are not installed, install the required Android SDK/Build Tools first.

## Edit pictures
Replace:
- `app/src/main/res/drawable-nodpi/launcher_background.png`
- `app/src/main/res/drawable-nodpi/voidxen_logo.png`
- `character_1.png`
- `character_2.png`
- `character_3.png`

Keep the same filenames and rebuild.

## Real game launch
The S1 screen currently represents the server flow. A real game launch must be connected to the Android package/deep link of a game you own/control; an arbitrary game file cannot be universally launched just from an IP/port.


## Landscape build
This version is configured for LANDSCAPE orientation. The launcher UI is designed around a wide 16:9 phone/tablet layout.
