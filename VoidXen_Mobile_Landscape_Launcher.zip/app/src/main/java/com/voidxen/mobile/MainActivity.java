package com.voidxen.mobile;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import android.net.Uri;
import java.util.*;

public class MainActivity extends Activity {
    FrameLayout root;
    LauncherView launcher;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,6,17));
        getWindow().setNavigationBarColor(Color.rgb(8,6,17));
        root = new FrameLayout(this);
        setContentView(root);
        showHome();
    }

    void showHome() { launcher = new LauncherView(this, 0); root.removeAllViews(); root.addView(launcher); }
    void showServer() { launcher = new LauncherView(this, 1); root.removeAllViews(); root.addView(launcher); }
    void showCharacters() { launcher = new LauncherView(this, 2); root.removeAllViews(); root.addView(launcher); }
    void showSpawn() { launcher = new LauncherView(this, 3); root.removeAllViews(); root.addView(launcher); }
    void showSettings() { launcher = new LauncherView(this, 4); root.removeAllViews(); root.addView(launcher); }
    void showRules() { launcher = new LauncherView(this, 5); root.removeAllViews(); root.addView(launcher); }
    void showSupport() { launcher = new LauncherView(this, 6); root.removeAllViews(); root.addView(launcher); }

    void openDiscord() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://discord.com/channels/1543459709237985322/1557053043839865002")));
        } catch(Exception ignored) {}
    }

    class LauncherView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap bg, logo, c1, c2, c3;
        int page;
        int W,H;

        int PURPLE = Color.rgb(180,92,255);
        int GOLD = Color.rgb(255,211,42);
        int GREEN = Color.rgb(82,231,104);
        int WHITE = Color.WHITE;
        int MUTED = Color.rgb(190,184,202);

        LauncherView(Context c, int page) {
            super(c);
            this.page = page;
            bg = load(com.voidxen.mobile.R.drawable.launcher_background);
            logo = load(com.voidxen.mobile.R.drawable.voidxen_logo);
            c1 = load(com.voidxen.mobile.R.drawable.character_1);
            c2 = load(com.voidxen.mobile.R.drawable.character_2);
            c3 = load(com.voidxen.mobile.R.drawable.character_3);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        Bitmap load(int id){ return BitmapFactory.decodeResource(getResources(), id); }

        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setShader(null); p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(size);
            p.setTypeface(Typeface.create("sans", bold?Typeface.BOLD:Typeface.NORMAL)); c.drawText(s,x,y,p);
        }
        void center(Canvas c,String s,float x,float y,float size,int color,boolean bold){
            p.setTextSize(size); p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));
            text(c,s,x-p.measureText(s)/2,y,size,color,bold);
        }
        void panel(Canvas c,float l,float t,float r,float b,int color,float rad){
            p.setShader(null); p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(l,t,r,b,rad,rad,p);
        }
        void line(Canvas c,float x1,float y1,float x2,float y2,int color,float w){
            p.setColor(color);p.setStrokeWidth(w);p.setStyle(Paint.Style.STROKE);c.drawLine(x1,y1,x2,y2,p);p.setStyle(Paint.Style.FILL);
        }

        @Override protected void onDraw(Canvas c) {
            W=getWidth(); H=getHeight();
            p.setAlpha(255);
            Rect src=new Rect(0,0,bg.getWidth(),bg.getHeight());
            Rect dst=new Rect(0,0,W,H);
            c.drawBitmap(bg,src,dst,p);
            p.setColor(Color.argb(80,0,0,0)); c.drawRect(0,0,W,H,p);
            if(page==0) home(c);
            else if(page==1) server(c);
            else if(page==2) characters(c);
            else if(page==3) spawn(c);
            else if(page==4) settings(c);
            else if(page==5) rules(c);
            else support(c);
        }

        void top(Canvas c,String title){
            text(c,"‹",24,58,44,WHITE,false);
            text(c,title,72,51,23,WHITE,true);
            text(c,"⚙",W-50,51,24,WHITE,false);
        }

        void home(Canvas c){
            text(c,"VOIDXEN",28,48,24,WHITE,true);
            text(c,"MOBILE",30,69,11,PURPLE,true);
            text(c,"● 1,684",W-115,50,14,GREEN,true);

            // logo
            Rect dst=new Rect((int)(W*.18f),130,(int)(W*.82f),300);
            p.setAlpha(245); c.drawBitmap(logo,null,dst,p); p.setAlpha(255);

            panel(c,28,335,W-28,455,Color.argb(150,12,7,25),24);
            text(c,"WELCOME TO VOIDXEN MOBILE",50,375,14,MUTED,true);
            text(c,"ROLEPLAY • CREATE • PLAY",50,402,19,WHITE,true);
            text(c,"S1  •  ONLINE",50,428,12,GREEN,true);

            panel(c,45,500,W-45,570,GOLD,16);
            center(c,"PLAY",W/2,545,21,Color.rgb(35,20,40),true);

            panel(c,45,590,W-45,650,Color.argb(205,145,70,230),16);
            center(c,"STORE",W/2,628,17,WHITE,true);

            panel(c,25,H-170,W/2-10,H-95,Color.argb(150,18,12,35),18);
            center(c,"⚙",W/4,H-133,24,PURPLE,false);
            center(c,"SETTINGS",W/4,H-112,11,WHITE,true);

            panel(c,W/2+10,H-170,W-25,H-95,Color.argb(150,18,12,35),18);
            center(c,"?",W*.75f,H-133,24,PURPLE,true);
            center(c,"SUPPORT",W*.75f,H-112,11,WHITE,true);

            center(c,"VoidXen Mobile  •  v1.0.0",W/2,H-35,10,MUTED,false);
        }

        void server(Canvas c){
            top(c,"SERVER");
            text(c,"SELECT SERVER",24,108,14,MUTED,true);
            panel(c,20,130,W-20,355,Color.argb(175,20,12,40),22);
            text(c,"# 001",38,170,25,WHITE,true);
            panel(c,W-105,147,W-38,178,Color.argb(180,105,45,170),13);
            center(c,"S1",W-71,169,12,WHITE,true);
            text(c,"●",38,204,16,GREEN,true);
            text(c,"ONLINE",61,204,12,GREEN,true);
            text(c,"188.127.241.74:1618",38,238,15,WHITE,false);
            text(c,"245 / 1000 players",38,265,13,MUTED,false);
            text(c,"ENGLISH",38,289,11,MUTED,true);
            panel(c,38,305,W-38,340,PURPLE,12);
            center(c,"SELECT S1",W/2,328,12,WHITE,true);
            text(c,"Only S1 is enabled in this version.",38,390,11,MUTED,false);
        }

        void characters(Canvas c){
            top(c,"CHARACTER SELECTION");
            text(c,"S1  •  CHOOSE CHARACTER",24,105,13,MUTED,true);
            drawChar(c,c1,25,145,W/3-18,430,"Character 1","Level 1","$ 0");
            drawChar(c,c2,W/3+8,145,2*W/3-8,430,"Character 2","Level 1","$ 0");
            drawChar(c,c3,2*W/3+15,145,W-25,430,"Character 3","Level 1","$ 0");
            panel(c,35,510,W-35,575,PURPLE,17);
            center(c,"CONTINUE",W/2,552,18,WHITE,true);
        }

        void drawChar(Canvas c,Bitmap b,float l,float t,float r,float bottom,String name,String lvl,String money){
            panel(c,l,t,r,bottom,Color.argb(120,42,20,65),18);
            Rect dst=new Rect((int)l+8,(int)t+8,(int)r-8,(int)t+315);
            c.drawBitmap(b,null,dst,p);
            text(c,name,l+15,t+350,13,WHITE,true);
            text(c,lvl,l+15,t+375,11,MUTED,false);
            text(c,money,l+15,t+400,12,GOLD,true);
        }

        void spawn(Canvas c){
            top(c,"SPAWN POINT");
            text(c,"S1  •  SELECT SPAWN",24,105,13,MUTED,true);
            String[] names={"EXIT POINT","RAILWAY STATION","APARTMENT","HOUSE","FAMILY"};
            float gap=14f, cardW=(W-40f-4*gap)/5f;
            for(int i=0;i<5;i++){
                float l=20+i*(cardW+gap);
                panel(c,l,140,l+cardW,470,Color.argb(155,28,15,48),18);
                text(c,names[i],l+10,500,10,WHITE,true);
                if(i>1) center(c,"LOCKED",l+cardW/2,310,12,WHITE,true);
            }
            panel(c,W/2-150,560,W/2+150,620,Color.argb(210,55,50,62),16);
            center(c,"Slide again to unlock",W/2,598,15,WHITE,false);
        }

        void settings(Canvas c){
            top(c,"SETTINGS");
            String[] a={"Game Settings","Graphics","Audio","Controls","Language     English","Notifications","Clear Cache","About VoidXen"};
            float y=100;
            for(String s:a){
                panel(c,20,y,W-20,y+52,Color.argb(150,17,11,32),14);
                text(c,s,37,y+33,14,WHITE,false);
                text(c,"›",W-43,y+34,21,MUTED,false);
                y+=62;
            }
        }

        void rules(Canvas c){
            top(c,"SERVER RULES");
            panel(c,20,95,W-20,180,Color.argb(160,18,12,34),18);
            text(c,"VOIDXEN MOBILE RULES",36,128,18,PURPLE,true);
            text(c,"Please respect players and staff.",36,153,12,MUTED,false);
            String[] rs={"No cheating or exploiting","No harassment or spam","Respect roleplay situations","Do not abuse bugs","Follow staff instructions"};
            float y=220;
            for(int i=0;i<rs.length;i++){
                text(c,String.valueOf(i+1),34,y,16,PURPLE,true);
                text(c,rs[i],66,y,14,WHITE,false);
                y+=54;
            }
        }

        void support(Canvas c){
            top(c,"SUPPORT");
            panel(c,20,100,W-20,275,Color.argb(165,18,12,34),20);
            text(c,"VOIDXEN SUPPORT",40,140,20,WHITE,true);
            text(c,"Report a player, ask for help,",40,168,13,MUTED,false);
            text(c,"or contact the administration team.",40,189,13,MUTED,false);
            panel(c,40,215,W-40,258,PURPLE,13);
            center(c,"OPEN DISCORD",W/2,243,13,WHITE,true);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();

            if(page==0){
                if(y>480 && y<585) showServer();
                else if(y>H-185 && y<H-80 && x<W/2) showSettings();
                else if(y>H-185 && y<H-80) showSupport();
            } else if(page==1){
                if(y>290 && y<360) showCharacters();
                else if(y<85) showHome();
            } else if(page==2){
                if(y>490 && y<600) showSpawn();
                else if(y<85) showServer();
            } else if(page==3){
                if(y<85) showCharacters();
            } else if(page==4){
                if(y<85) showHome();
            } else if(page==5){
                if(y<85) showHome();
            } else {
                if(y>210 && y<280) openDiscord();
                else if(y<85) showHome();
            }
            invalidate();
            return true;
        }
    }
}
