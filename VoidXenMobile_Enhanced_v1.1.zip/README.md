# VoidXen Mobile — Android Launcher

This is an Android Studio / Gradle project for the VoidXen Mobile launcher.

## Updated in this revision

- Google sign-in button now opens a clear setup dialog and takes the user to Settings when the OAuth client ID is missing.
- Google Sign-In uses Android Credential Manager. Once configured with a valid Google **Web application OAuth client ID**, tapping GOOGLE opens Google's account chooser.
- Added an original, locally synthesized ambient instrumental loop (`voidxen_ambient.ogg`) with a Background music toggle.
- Added game FPS limit choices (30 / 45 / 60 / 90 / 120 / Unlimited).
- Added a Show FPS counter in game preference.
- Added animated cinematic background toggle.
- Existing loading/connect stages, progress UI, downloads, notifications, server list, rules/support, language and graphics settings are preserved.
- Server IP/port are not displayed on the server cards; addresses remain in the launcher configuration.
- Updated the three configured VoidXen server addresses.

## Google sign-in setup (required)

Google OAuth cannot be made functional by code alone. Each app owner must configure OAuth in their own Google Cloud project.

1. Open Google Cloud Console → APIs & Services → Credentials.
2. Configure the OAuth consent screen.
3. Create an **OAuth Client ID → Web application**. Copy the Web client ID.
4. Also register an Android OAuth client for package `com.voidxen.mobile` using the signing SHA-1 shown below.
5. Open VoidXen Mobile → Guest → Settings → Google client ID, then paste the **Web application client ID**.
6. Tap GOOGLE again. Android Credential Manager should display the Google account chooser.

Signing SHA-1 for the included development keystore:
`5F:3E:97:FA:50:24:04:2F:CC:8D:9B:D9:DC:13:52:2D:6E:4E:CC:40`

The bundled keystore is a development key and should not be used for a public production release. Create and protect your own signing key before publishing.

## Discord sign-in

Set your Discord OAuth2 client ID in Settings. Add this redirect URI in Discord Developer Portal:
`voidxen://auth`

A production account backend is optional but recommended. Configure `authApiUrl` to an HTTPS backend that verifies Google ID tokens / Discord identity and issues your own session token.

## Remote server configuration

Host a JSON file at a direct HTTPS URL (Dropbox direct-download link is supported), then use Settings → Server config link.

Example:

```json
{
  "servers": [
    {
      "name": "001",
      "ip": "188.127.241.74",
      "port": "1618",
      "downloadUrl": "",
      "downloadFile": "game.apk",
      "version": "1",
      "gamePackage": "YOUR.INSTALLED.GAME.PACKAGE"
    }
  ]
}
```

Fields:
- `ip`, `port`: server address passed to the game client.
- `downloadUrl`: direct HTTPS download URL for an APK or ZIP.
- `downloadFile`: filename ending in `.apk` or `.zip`.
- `version`: change this to trigger an update.
- `sha256`: optional SHA-256 integrity check.
- `gamePackage`: Android package name of the installed game app.
- `statusUrl`: optional JSON status endpoint.

## Important game-file compatibility limits

A launcher is not a universal game emulator. It cannot make every arbitrary file playable.

- `.apk`: downloaded and offered to Android for installation.
- `.zip`: safely extracted into the launcher's private game data directory.
- A ZIP containing game data still needs a compatible installed Android game application.
- `gamePackage` must be set to that installed game's actual package name.
- The game client must support the launch intent extras sent by this launcher: `nickname`, `auth_token`, `server_name`, `server_ip`, `server_port`, `graphics_quality`, `fps_limit`, `show_fps_counter`, `language`, and `data_dir`.
- FPS limit and in-game FPS display are preferences passed to the game. They only take effect if the game client implements those extras.
- A random `.pwn`, `.so`, `.dex`, `.obb`, or data folder cannot be launched directly as an Android game by this launcher. Those files must be integrated by the actual game/client.

The launcher does not fabricate a successful connection if the game package or required game files are missing.

## Build with GitHub Actions

1. Extract the ZIP.
2. Upload the **contents** of the extracted project folder to the repository root. The root must contain `settings.gradle.kts`, `build.gradle.kts`, `launcher.properties`, and `app/`.
3. Keep `.github/workflows/build.yml` in the repository.
4. Open GitHub → Actions → Build VoidXen Mobile APK → Run workflow.
5. Download the `VoidXen-Mobile-APK` artifact when the workflow succeeds.

Build requirements: JDK 17, Android SDK platform 34, Build Tools 34.0.0, Gradle 8.7.

## Project configuration

- Build/app name and signing values: `launcher.properties`
- Servers, OAuth IDs, support/news/config URLs: `app/src/main/assets/launcher_config.json`
- UI and sign-in: `app/src/main/java/com/voidxen/launcher/`
- Original ambient music: `app/src/main/assets/voidxen_ambient.ogg`
- Background images: `app/src/main/res/drawable-nodpi/bg_sharp.jpg` and `bg_blur.jpg`

The project ZIP size is not artificially padded. A 60 MB+ package would require real game assets/client files supplied by the owner; adding empty filler data would only increase download size without making the game work.
