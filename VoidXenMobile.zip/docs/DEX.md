# DEX integration (classes.dex ... classesN.dex)

1. Gradle (D8) khud DEX files banata hai. minSdk 24 par native multidex hai, to
   classes.dex, classes2.dex, classes3.dex, classes4.dex... jitni zarurat ho utni apne aap bante hain.
   Count aapke code + libraries ke size par depend karta hai; use manually force nahi kiya jata.
2. Apna code jodne ke 3 sahi tarike:
   - source files: `app/src/main/java/...`
   - library module / AAR / JAR: JAR ko `app/libs/` me rakho aur `implementation(files("libs/x.jar"))`
   - Maven dependency: `implementation("group:artifact:version")`
3. Duplicate classes: `gradle :app:checkDebugDuplicateClasses` (assemble ke saath khud chalta hai).
   Error aaye to dependency versions align karo ya `exclude(group = "...", module = "...")` lagao.
4. Built APK ke andar DEX files hath se mat badlo / overwrite mat karo: signature toot jata hai,
   duplicate class ya VerifyError aata hai. Hamesha source se rebuild karo.
5. Compatibility check: GitHub Actions har build me APK ke andar ki DEX files list karta hai
   ("DEX files inside APK" step).
6. Sirf apna ya likhit anumati wala code/APK modify karo. Ye launcher kisi dusre app ko modify nahi karta:
   wo aapka game package download karke (Dropbox) install karta aur Intent se launch karta hai.
