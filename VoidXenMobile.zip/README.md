# VoidXen Mobile — Android Launcher

This archive contains the Android source project and its GitHub Actions workflow.

## Launcher features
- English-first game launcher UI with Login, Home, News, Support, Servers, Connect and Settings screens.
- Google, Discord and Guest login entry points.
- Three configured VoidXen servers:
  - `001` — `188.127.241.74:1618`
  - `002` — `188.127.241.74:2541`
  - `003` — `188.127.241.74:1724`
- Server IP/port are hidden from server cards by default. They remain in the internal configuration and are passed to the compatible game client.
- Live server status via a configured JSON `statusUrl` or SA-MP UDP query where supported.
- Resumable downloads, progress, optional SHA-256 validation, ZIP extraction with zip-slip protection, and APK install prompt.
- Settings: graphics quality, game FPS target extra, launcher FPS overlay, show/hide server addresses, Wi-Fi-only downloads, notifications, keep-screen-awake, language, remote config, custom background, account controls, and device/performance information.
- New original high-resolution sunset coastal city and speedboat background, plus a blurred version for secondary screens.
- README and separate workflow file are included.

## Important behavior notes
- **Launcher FPS counter** measures this launcher's UI frame rate only. It does not measure the game client's FPS.
- **Game FPS target** is passed to the game as the `fps_limit` launch extra. The game client must explicitly read and implement that extra; a launcher cannot force FPS in a separate game process.
- Graphics quality is passed to the game as `graphics_quality`; the game client must support it.
- Google Sign-In requires a valid Google OAuth **Web application Client ID** and a matching Android OAuth client configured in Google Cloud Console for package `com.voidxen.mobile` and the signing certificate SHA-1. The client ID is not included because it belongs to the app owner.
- Discord login requires a Discord OAuth2 application Client ID and redirect URI `voidxen://auth`. If the IDs are blank, those sign-in providers cannot complete login; Guest login remains available.
- Backend account verification requires an HTTPS `authApiUrl` endpoint. Without it, the launcher stores a local profile only.
- Actual game launch requires the compatible game app to be installed and its package name configured as `gamePackage`. The launcher passes nickname, token, server name/IP/port, graphics quality, FPS target, language and data directory as intent extras.
- Live player count depends on the server's query protocol or a working status API. It is not fabricated.
- This is launcher software, not a 60 MB game client. Do not inflate the APK with dummy files. Add the actual licensed game assets/client if a larger game package is required.

## Remote JSON configuration
Host a JSON file over HTTPS and set its URL in Settings → Server config link. Example:

```json
{
  "servers": [
    {"name":"001","firstname":"001","ip":"188.127.241.74","port":"1618","statusUrl":""},
    {"name":"002","firstname":"002","ip":"188.127.241.74","port":"2541","statusUrl":""},
    {"name":"003","firstname":"003","ip":"188.127.241.74","port":"1724","statusUrl":""}
  ],
  "supportUrl": "https://example.com/support",
  "backgroundUrl": "https://example.com/launcher-background.jpg"
}
```

Dropbox share URLs are normalized to direct-download links by the launcher. For a custom background, use a direct HTTPS image URL.

## Google Sign-In setup
1. In Google Cloud Console, create an OAuth client of type **Web application** and copy its Client ID.
2. Create an Android OAuth client for package `com.voidxen.mobile` and the SHA-1 of the signing key used to build the APK.
3. Open launcher Settings → Google Client ID and paste the Web application Client ID.
4. Rebuild and test on the same signing configuration.
5. If signing key changes, update the Android OAuth client's SHA-1.

The repository includes a development signing keystore from the supplied project. Treat it as public and replace it with a private release key before publishing.

## Build with GitHub Actions
1. Extract this ZIP.
2. Upload the **contents** of the extracted folder to the root of your GitHub repository (do not upload only the ZIP).
3. Confirm `.github/workflows/build.yml` exists.
4. Open GitHub → Actions → **Build VoidXen Mobile APK** → Run workflow.
5. Download the `VoidXen-Mobile-APK` artifact from the successful run.

The workflow uses JDK 17, Android SDK platform 34 and Gradle 8.7, matching this project's Android Gradle Plugin 8.5.2.

## Project layout
- `app/` Android app source and resources
- `app/src/main/assets/launcher_config.json` bundled runtime configuration
- `launcher.properties` app ID, version, APK name and build type
- `.github/workflows/build.yml` APK build workflow
- `docs/DEX.md` DEX inspection notes
