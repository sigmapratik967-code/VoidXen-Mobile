package com.voidxen.launcher

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.app.ActivityManager
import android.os.BatteryManager
import android.os.StatFs
import android.content.IntentFilter
import android.view.Choreographer
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

// Reference video se liye gaye colours
private val C_YELLOW = Color.parseColor("#F7CA2A")
private val C_PURPLE = Color.parseColor("#CA6FFD")
private val C_GREEN = Color.parseColor("#65EF00")
private val C_DIM = Color.parseColor("#B9ABD3")
private val C_RED = Color.parseColor("#FF6B6B")
private val C_CARD = Color.parseColor("#381A58")
private val C_STROKE = Color.parseColor("#4A2A75")
private val C_BTN_TEXT = Color.parseColor("#2D1457")

class MainActivity : AppCompatActivity() {

    private enum class St { DOWNLOAD, UPDATE, INSTALL, PLAY, NOCONFIG }

    private class CardHolder(
        val cfg: ServerCfg,
        val count: TextView,
        val progressRow: LinearLayout,
        val progress: ProgressBar,
        val pct: TextView,
        val button: TextView,
        val hint: TextView
    ) {
        fun setProgress(done: Long, total: Long) {
            if (total > 0) {
                progress.isIndeterminate = false
                progress.progress = (done * 100 / total).toInt()
                pct.text = "${done * 100 / total}%   ${mb(done)} / ${mb(total)} MB"
            } else {
                progress.isIndeterminate = true
                pct.text = "${mb(done)} MB"
            }
        }

        private fun mb(b: Long): String = "%.1f".format(b / 1048576.0)
    }

    private lateinit var cfg: AppConfig
    private lateinit var ui: GameUi
    private val prefs by lazy { getSharedPreferences("voidxen", Context.MODE_PRIVATE) }
    private var player = ""
    private var balance = "—"
    private var newsList: List<NewsItem> = emptyList()

    private val stack = ArrayDeque<Int>()
    private lateinit var screens: Map<Int, View>
    private val handler = Handler(Looper.getMainLooper())
    private val holders = LinkedHashMap<String, CardHolder>()
    private val statuses = HashMap<String, Status?>()
    private val running = HashMap<String, AtomicBoolean>()
    private val balanceViews = ArrayList<TextView>()
    private val actionViews = ArrayList<TextView>()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var fpsOverlay: TextView? = null
    private var fpsCallback: Choreographer.FrameCallback? = null
    private var fpsFrames = 0
    private var fpsWindowStart = 0L

    private val pollTask = object : Runnable {
        override fun run() {
            refreshStatuses()
            fetchProfile()
            handler.postDelayed(this, 15000)
        }
    }

    // ------------------------------------------------------------ lifecycle
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)
        ui = GameUi(this, findViewById<FrameLayout>(R.id.rootFrame))
        startKenBurns()

        val base = ConfigLoader.fromAssets(this)
        cfg = try {
            prefs.getString("remote_cache", null)?.let { ConfigLoader.parse(it, base) } ?: base
        } catch (e: Exception) {
            base
        }
        player = prefs.getString("player", "") ?: ""
        newsList = cfg.news
        loadBackground()

        screens = listOf(R.id.splash, R.id.home, R.id.servers, R.id.settings, R.id.login, R.id.connect)
            .associateWith { findViewById<View>(it) }

        addHeader(R.id.servers, R.string.servers_title, true)
        addHeader(R.id.settings, R.string.settings_title, false)
        wireHome()
        wireLogin()
        wireConnect()
        buildServers()
        refreshPlayer()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!ui.dismissDialog()) goBack()
            }
        })

        show(R.id.splash, push = false)
        handler.postDelayed({
            if (loggedIn()) {
                stack.clear()
                show(R.id.home)
            } else {
                showLogin()
            }
        }, 1800)
        loadRemote(false)
        handleOAuthReturn(intent)
    }

    override fun onResume() {
        super.onResume()
        holders.values.forEach { updateCard(it) }
        startFpsMonitor()
        if (prefs.getBoolean("keep_awake", false)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (stack.lastOrNull() == R.id.connect && findViewById<View>(R.id.connectResult).visibility == View.VISIBLE) {
            connectServer?.let { runConnect(it) }
        }
        kenBurns.forEach { it.resume() }
        handler.removeCallbacks(pollTask)
        handler.post(pollTask)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(pollTask)
        stopFpsMonitor()
        kenBurns.forEach { it.pause() }
    }

    // ------------------------------------------------------------ home + header
    private fun wireHome() {
        registerBalance(findViewById(R.id.tvBalanceHome))
        findViewById<View>(R.id.btnPlay).setOnClickListener { show(R.id.servers) }
        findViewById<View>(R.id.btnNews).setOnClickListener { showNews() }
        findViewById<View>(R.id.btnSupport).setOnClickListener { openUrl(cfg.supportUrl) }
        findViewById<View>(R.id.btnSettings).setOnClickListener { buildSettings(); show(R.id.settings) }
        findViewById<View>(R.id.tvPlayer).setOnClickListener {
            buildSettings()
            show(R.id.settings)
        }
    }

    private fun registerBalance(tv: TextView) {
        tv.text = balance
        balanceViews.add(tv)
    }

    private fun addHeader(screenId: Int, @StringRes title: Int, showRules: Boolean) {
        val parent = findViewById<LinearLayout>(screenId)
        val v = layoutInflater.inflate(R.layout.view_header, parent, false)
        v.findViewById<TextView>(R.id.hTitle).setText(title)
        v.findViewById<View>(R.id.hBack).setOnClickListener { goBack() }
        v.findViewById<View>(R.id.hSupport).setOnClickListener { openUrl(cfg.supportUrl) }
        registerBalance(v.findViewById<TextView>(R.id.hBalance))
        val action = v.findViewById<TextView>(R.id.hAction)
        action.paintFlags = action.paintFlags or Paint.UNDERLINE_TEXT_FLAG
        if (showRules) {
            actionViews.add(action)
            action.setOnClickListener { openUrl(cfg.rulesUrl) }
        }
        parent.addView(v, 0)
        updateHeaderActions()
    }

    private fun updateHeaderActions() {
        actionViews.forEach { it.visibility = if (cfg.rulesUrl.isNotBlank()) View.VISIBLE else View.GONE }
    }

    // ------------------------------------------------------------ player name
    private fun refreshPlayer() {
        findViewById<TextView>(R.id.tvPlayer).text = if (player.isBlank()) getString(R.string.nick_prompt) else player
    }

    // ------------------------------------------------------------ remote config / news / profile
    private fun loadRemote(showToast: Boolean) {
        val url = (prefs.getString("cfg_url", "") ?: "").ifBlank { cfg.remoteConfigUrl }
        if (url.isBlank()) {
            loadNews()
            return
        }
        Thread {
            try {
                val text = Net.getText(url)
                val parsed = ConfigLoader.parse(text, ConfigLoader.fromAssets(this))
                prefs.edit().putString("remote_cache", text).apply()
                runOnUiThread {
                    cfg = parsed
                    loadBackground()
                    buildServers()
                    updateHeaderActions()
                    refreshStatuses()
                    if (showToast) toast(R.string.msg_cfg_ok)
                    loadNews()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (showToast) toast(R.string.msg_cfg_fail)
                    loadNews()
                }
            }
        }.start()
    }

    private fun loadNews() {
        val url = cfg.newsUrl
        if (url.isBlank()) {
            newsList = cfg.news
            return
        }
        Thread {
            try {
                val items = ConfigLoader.parseNews(JSONArray(Net.getText(url)))
                runOnUiThread { newsList = items }
            } catch (e: Exception) {
                runOnUiThread { newsList = cfg.news }
            }
        }.start()
    }

    private fun fetchProfile() {
        val base = cfg.profileApiUrl
        if (base.isBlank() || player.isBlank()) return
        val url = base + (if (base.contains("?")) "&" else "?") + "nick=" + Net.enc(player)
        Thread {
            try {
                val v = JSONObject(Net.getText(url)).optString("balance", "")
                if (v.isNotBlank()) {
                    runOnUiThread {
                        balance = v
                        balanceViews.forEach { it.text = v }
                    }
                }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun showNews() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        if (newsList.isEmpty()) {
            box.addView(tv(getString(R.string.news_empty), 14f, C_DIM))
        } else {
            newsList.forEach { n ->
                if (n.title.isNotBlank()) box.addView(tv(n.title, 15f, C_YELLOW, true))
                if (n.text.isNotBlank()) {
                    val t = tv(n.text, 13f, Color.WHITE)
                    t.setPadding(0, dp(3), 0, 0)
                    box.addView(t)
                }
                val d = tv(n.date, 11f, C_DIM)
                d.setPadding(0, dp(3), 0, dp(14))
                if (n.date.isNotBlank()) box.addView(d)
            }
        }
        ui.dialog(getString(R.string.news_title), null, box, listOf(GameUi.Btn(getString(R.string.close), true) { }))
    }

    // ------------------------------------------------------------ live status
    private fun refreshStatuses() {
        cfg.servers.forEach { s ->
            Thread {
                val st = StatusRepo.fetch(s)
                runOnUiThread {
                    statuses[s.name] = st
                    holders[s.name]?.let { updateCard(it) }
                    updateTotal()
                }
            }.start()
        }
    }

    private fun updateTotal() {
        val known = statuses.values.filterNotNull().filter { it.online && it.players != null }
        findViewById<TextView>(R.id.tvOnline).text =
            if (known.isEmpty()) "●  —" else "●  " + fmt(known.sumOf { it.players ?: 0 })
    }

    private fun fmt(n: Int): String = n.toString().reversed().chunked(3).joinToString(" ").reversed()

    // ------------------------------------------------------------ server cards
    private fun buildServers() {
        val grid = findViewById<GridLayout>(R.id.serverGrid)
        grid.removeAllViews()
        holders.clear()
        cfg.servers.forEach { s ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(6).toFloat()
                    setColor(C_CARD)
                    setStroke(dp(if (s.color != null) 2 else 1), s.color ?: C_STROKE)
                }
                setPadding(dp(12), dp(10), dp(12), dp(10))
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply { width = 0; setMargins(dp(6), dp(6), dp(6), dp(6)) }
            }

            val count = tv("…", 12f, C_DIM)
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            top.addView(tv("#", 13f, C_DIM))
            top.addView(tv(" ${s.first}", 15f, Color.WHITE, true))
            if (s.second.isNotBlank()) {
                top.addView(chip(s.second), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            }
            if (s.x2) top.addView(tv("  x2", 12f, C_YELLOW, true))
            top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            top.addView(count)
            card.addView(top)

            // IP/port hidden from the public server cards by default.
            if (prefs.getBoolean("show_server_address", false)) {
                val addr = tv(if (s.ip.isBlank()) "" else "${s.ip}:${s.port}", 11f, C_DIM)
                addr.setPadding(0, dp(6), 0, 0)
                card.addView(addr)
            }
            val hint = tv("", 11f, C_YELLOW)
            hint.setPadding(0, dp(2), 0, 0)
            card.addView(hint)

            val progressRow = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(0, dp(8), 0, 0)
            }
            val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                progressTintList = ColorStateList.valueOf(C_YELLOW)
            }
            val pct = tv("", 11f, C_DIM)
            progressRow.addView(progress, LinearLayout.LayoutParams(-1, dp(6)))
            progressRow.addView(pct)
            card.addView(progressRow)

            val button = tv("", 13f, C_BTN_TEXT, true).apply { gravity = Gravity.CENTER }
            button.setOnClickListener { onCardAction(s) }
            card.addView(button, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(10) })

            val h = CardHolder(s, count, progressRow, progress, pct, button, hint)
            holders[s.name] = h
            grid.addView(card)
            updateCard(h)
        }
    }

    private fun updateCard(h: CardHolder) {
        val s = h.cfg
        val st = statuses[s.name]
        val label: String
        val color: Int
        if (s.ip.isBlank() && s.statusUrl.isBlank()) {
            label = "—"; color = C_DIM
        } else if (!statuses.containsKey(s.name)) {
            label = "…"; color = C_DIM
        } else if (st == null) {
            label = getString(R.string.st_unknown); color = C_DIM
        } else if (!st.online) {
            label = "●  " + getString(R.string.st_offline); color = C_RED
        } else if (st.players != null && st.max != null) {
            label = "●  ${fmt(st.players)}/${st.max}"; color = C_GREEN
        } else {
            label = "●  " + getString(R.string.st_online); color = C_GREEN
        }
        h.count.text = label
        h.count.setTextColor(color)

        val busy = running.containsKey(s.name)
        h.button.setText(if (busy) R.string.btn_cancel else R.string.btn_play)
        h.button.background = pill(if (busy) C_PURPLE else C_YELLOW)

        h.hint.visibility = View.GONE
    }

    private fun stateOf(s: ServerCfg): St {
        val installed = s.gamePackage.isNotBlank() && isInstalled(s.gamePackage)
        if (s.downloadUrl.isBlank()) return if (installed) St.PLAY else St.NOCONFIG
        val saved = prefs.getString("ver_${s.name}", null)
        val file = GameManager.localFile(this, s)
        return when {
            saved == null -> if (installed) St.PLAY else St.DOWNLOAD
            saved != s.version -> St.UPDATE
            GameManager.isApk(s) && !installed -> if (file.exists()) St.INSTALL else St.DOWNLOAD
            else -> St.PLAY
        }
    }

    private fun onCardAction(s: ServerCfg) {
        val cancel = running[s.name]
        if (cancel != null) {
            cancel.set(true)
            return
        }
        startConnect(s)
    }

    // ------------------------------------------------------------ download / install / launch
    private fun startDownload(s: ServerCfg) {
        if (prefs.getBoolean("wifi_only", true) && !onWifi()) {
            toast(R.string.msg_wifi)
            return
        }
        val flag = AtomicBoolean(false)
        running[s.name] = flag
        holders[s.name]?.let {
            it.progressRow.visibility = View.VISIBLE
            it.setProgress(0, -1)
            updateCard(it)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            try {
                val dest = GameManager.localFile(this, s)
                Downloader.download(s.downloadUrl, dest, s.sha256, flag) { done, total ->
                    runOnUiThread {
                        holders[s.name]?.setProgress(done, total)
                        onConnectProgress(s, done, total)
                    }
                }
                if (dest.name.endsWith(".zip", ignoreCase = true)) {
                    GameManager.unzip(dest, GameManager.dataDir(this, s))
                }
                prefs.edit().putString("ver_${s.name}", s.version).apply()
                runOnUiThread { finishDownload(s, 0, "") }
            } catch (e: DownloadCancelled) {
                runOnUiThread { finishDownload(s, 1, "") }
            } catch (e: Exception) {
                runOnUiThread { finishDownload(s, 2, e.message ?: "error") }
            }
        }.start()
    }

    // result: 0 = ok, 1 = paused, 2 = failed
    private fun finishDownload(s: ServerCfg, result: Int, msg: String) {
        finishDownloadInner(s, result, msg)
        onConnectDone(s)
    }

    private fun finishDownloadInner(s: ServerCfg, result: Int, msg: String) {
        running.remove(s.name)
        if (running.isEmpty()) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        holders[s.name]?.let {
            it.progressRow.visibility = View.GONE
            updateCard(it)
        }
        when (result) {
            0 -> {
                toast(R.string.msg_dl_done)
                postNotification(getString(R.string.msg_dl_done))
                if (GameManager.isApk(s) && stateOf(s) == St.INSTALL) installApk(s)
            }
            1 -> toast(R.string.msg_paused)
            else -> {
                toast(R.string.msg_dl_fail, msg)
                postNotification(getString(R.string.msg_dl_fail, msg))
            }
        }
    }

    private fun installApk(s: ServerCfg) {
        val f = GameManager.localFile(this, s)
        if (!f.exists()) {
            toast(R.string.msg_install_missing)
            return
        }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            toast(R.string.msg_allow_install)
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun postNotification(text: String) {
        if (!prefs.getBoolean("notif", true)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = NotificationManagerCompat.from(this)
        nm.createNotificationChannel(
            NotificationChannelCompat.Builder("downloads", NotificationManagerCompat.IMPORTANCE_DEFAULT)
                .setName("Downloads").build()
        )
        val n = NotificationCompat.Builder(this, "downloads")
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(1001, n)
    }

    // ------------------------------------------------------------ settings screen
    private fun buildSettings() {
        val list = findViewById<LinearLayout>(R.id.settingsList)
        list.removeAllViews()
        list.addView(row(getString(R.string.set_account), "$player  ·  " + getString(R.string.logout)) { logout() })
        list.addView(row(getString(R.string.set_graphics), qualityLabel()) { pickGraphics() })
        list.addView(switchRow(getString(R.string.set_wifi), prefs.getBoolean("wifi_only", true)) {
            prefs.edit().putBoolean("wifi_only", it).apply()
        })
        list.addView(row(getString(R.string.set_clear), null) { clearFiles() })
        list.addView(row(getString(R.string.set_lang), langLabel()) { pickLanguage() })
        list.addView(switchRow(getString(R.string.set_notif), prefs.getBoolean("notif", true)) { on ->
            prefs.edit().putBoolean("notif", on).apply()
            if (on && Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        })
        list.addView(row(getString(R.string.set_google_id), idLabel(googleId())) { editId("google_id", R.string.set_google_id) })
        list.addView(row(getString(R.string.set_discord_id), idLabel(discordId())) { editId("discord_id", R.string.set_discord_id) })
        list.addView(row(getString(R.string.set_cfg), null) { editConfigLink() })
        list.addView(row("Launcher background image URL", if (backgroundUrl().isBlank()) "Bundled artwork" else "Custom image set") { editBackgroundUrl() })
        list.addView(row(getString(R.string.set_support), null) { openUrl(cfg.supportUrl) })
        list.addView(switchRow("Show server IP and port", prefs.getBoolean("show_server_address", false)) {
            prefs.edit().putBoolean("show_server_address", it).apply()
            buildServers()
        })
        list.addView(switchRow("Show launcher FPS counter", prefs.getBoolean("show_fps", false)) {
            prefs.edit().putBoolean("show_fps", it).apply()
            if (it) startFpsMonitor() else stopFpsMonitor()
        })
        list.addView(row("Game FPS target", fpsLimitLabel()) { pickFpsLimit() })
        list.addView(switchRow("Keep screen awake in launcher", prefs.getBoolean("keep_awake", false)) {
            prefs.edit().putBoolean("keep_awake", it).apply()
            if (it) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else if (running.isEmpty()) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        })
        list.addView(row("Device & performance", "View details") { showDeviceInfo() })
        list.addView(row("Google sign-in setup", if (googleId().isBlank()) "Not configured" else "Client ID saved") {
            ui.dialog(
                "Google sign-in setup",
                "Google login needs a Google OAuth Web application Client ID and a matching Android OAuth client for package com.voidxen.mobile. Add the Web Client ID in the Google Client ID setting. A valid ID cannot be generated inside this launcher.",
                null,
                listOf(GameUi.Btn(getString(R.string.close), true) { })
            )
        })
        list.addView(row(getString(R.string.set_version), versionName(), null))
    }

    private fun fpsLimitLabel(): String = prefs.getString("fps_limit", "60") ?: "60"

    private fun pickFpsLimit() {
        val values = listOf("30", "45", "60", "90", "120", "Unlimited")
        val current = values.indexOf(fpsLimitLabel()).let { if (it < 0) 2 else it }
        ui.choice("Game FPS target", values, current, getString(R.string.cancel)) { index ->
            prefs.edit().putString("fps_limit", values[index]).apply()
            buildSettings()
        }
    }

    private fun showDeviceInfo() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val stat = StatFs(filesDir.absolutePath)
        val free = stat.availableBytes / (1024L * 1024L)
        val total = stat.totalBytes / (1024L * 1024L)
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val totalRam = mi.totalMem / (1024L * 1024L)
        val availRam = mi.availMem / (1024L * 1024L)
        val details = "Device: ${Build.MANUFACTURER} ${Build.MODEL}\\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\\nRAM: ${totalRam - availRam} MB used / ${totalRam} MB total\\nApp storage: ${free} MB free / ${total} MB total\\nBattery: ${if (percent >= 0) "$percent%" else "Unavailable"}\\nLauncher FPS: UI frame rate only\\nGame FPS target: ${fpsLimitLabel()} (game client must support the extra)"
        ui.dialog("Device & performance", details, null, listOf(GameUi.Btn(getString(R.string.close), true) { }))
    }

    private fun startFpsMonitor() {
        if (!prefs.getBoolean("show_fps", false)) {
            stopFpsMonitor()
            return
        }
        val root = findViewById<FrameLayout>(R.id.rootFrame)
        if (fpsOverlay == null) {
            fpsOverlay = TextView(this).apply {
                text = "Launcher FPS: --"
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                background = GradientDrawable().apply {
                    setColor(0xCC160D24.toInt())
                    cornerRadius = dp(8).toFloat()
                    setStroke(dp(1), C_YELLOW)
                }
                elevation = dp(8).toFloat()
            }
            root.addView(fpsOverlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
                topMargin = dp(12); marginEnd = dp(12)
            })
        }
        fpsOverlay?.visibility = View.VISIBLE
        if (fpsCallback != null) return
        fpsFrames = 0
        fpsWindowStart = 0L
        lateinit var callback: Choreographer.FrameCallback
        callback = Choreographer.FrameCallback {
            if (!prefs.getBoolean("show_fps", false) || isFinishing) {
                stopFpsMonitor()
                return@FrameCallback
            }
            fpsFrames++
            val now = SystemClock.elapsedRealtime()
            if (fpsWindowStart == 0L) fpsWindowStart = now
            if (now - fpsWindowStart >= 1000L) {
                val fps = (fpsFrames * 1000L / (now - fpsWindowStart)).toInt()
                fpsOverlay?.text = "Launcher FPS: $fps"
                fpsFrames = 0
                fpsWindowStart = now
            }
            Choreographer.getInstance().postFrameCallback(callback)
        }
        fpsCallback = callback
        Choreographer.getInstance().postFrameCallback(callback)
    }

    private fun stopFpsMonitor() {
        fpsCallback?.let { Choreographer.getInstance().removeFrameCallback(it) }
        fpsCallback = null
        fpsOverlay?.let { (it.parent as? android.view.ViewGroup)?.removeView(it) }
        fpsOverlay = null
    }

    private fun qualityLabel(): String = when (prefs.getString("graphics", "medium")) {
        "low" -> getString(R.string.q_low)
        "high" -> getString(R.string.q_high)
        else -> getString(R.string.q_med)
    }

    private fun pickGraphics() {
        val keys = listOf("low", "medium", "high")
        val items = listOf(getString(R.string.q_low), getString(R.string.q_med), getString(R.string.q_high))
        val cur = keys.indexOf(prefs.getString("graphics", "medium")).let { if (it < 0) 1 else it }
        ui.choice(getString(R.string.set_graphics), items, cur, getString(R.string.cancel)) { i ->
            prefs.edit().putString("graphics", keys[i]).apply()
            buildSettings()
        }
    }

    private fun langTag(): String =
        AppCompatDelegate.getApplicationLocales().toLanguageTags().substringBefore('-')

    private fun langLabel(): String = when (langTag()) {
        "en" -> "English"
        "hi" -> "हिन्दी"
        else -> getString(R.string.lang_system)
    }

    private fun pickLanguage() {
        val tags = listOf("", "en", "hi")
        val names = listOf(getString(R.string.lang_system), "English", "हिन्दी")
        val cur = tags.indexOf(langTag()).let { if (it < 0) 0 else it }
        ui.choice(getString(R.string.set_lang), names, cur, getString(R.string.cancel)) { i ->
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tags[i]))
        }
    }

    private fun clearFiles() {
        ui.confirm(
            getString(R.string.set_clear), getString(R.string.confirm_clear),
            getString(R.string.ok), getString(R.string.cancel)
        ) { doClearFiles() }
    }

    private fun doClearFiles() {
        running.values.forEach { it.set(true) }
        GameManager.clearAll(this)
        val e = prefs.edit()
        cfg.servers.forEach { e.remove("ver_${it.name}") }
        e.apply()
        holders.values.forEach { updateCard(it) }
        toast(R.string.msg_cleared)
    }

    // Sign-in client IDs: app ke andar bhi daal sakte ho (config JSON ki zarurat nahi)
    private fun googleId(): String = (prefs.getString("google_id", "") ?: "").ifBlank { cfg.googleClientId }
    private fun discordId(): String = (prefs.getString("discord_id", "") ?: "").ifBlank { cfg.discordClientId }
    private fun idLabel(id: String): String = getString(if (id.isBlank()) R.string.id_not_set else R.string.id_set)

    private fun editId(key: String, @StringRes title: Int) {
        ui.input(
            getString(title), getString(R.string.set_id_msg), "Client ID", prefs.getString(key, "") ?: "",
            getString(R.string.save), getString(R.string.reset), getString(R.string.cancel),
            onSave = { v ->
                prefs.edit().putString(key, v).apply()
                buildSettings()
            },
            onReset = {
                prefs.edit().remove(key).apply()
                buildSettings()
            }
        )
    }

    private fun backgroundUrl(): String =
        (prefs.getString("background_url", "") ?: "").ifBlank { cfg.backgroundUrl }

    private fun editBackgroundUrl() {
        ui.input(
            "Launcher background image",
            "Paste a direct HTTPS image URL. Leave it blank to use the bundled sunset boat-and-city artwork.",
            "https://example.com/background.jpg",
            backgroundUrl(),
            getString(R.string.save), getString(R.string.reset), getString(R.string.cancel),
            onSave = { value ->
                if (value.isNotBlank() && !value.startsWith("https://", true)) {
                    toast(R.string.msg_no_url)
                } else {
                    prefs.edit().putString("background_url", value).apply()
                    loadBackground()
                    buildSettings()
                }
            },
            onReset = {
                prefs.edit().remove("background_url").apply()
                loadBackground()
                buildSettings()
            }
        )
    }

    private fun editConfigLink() {
        ui.input(
            getString(R.string.set_cfg), getString(R.string.cfg_msg), "https://www.dropbox.com/...",
            prefs.getString("cfg_url", "") ?: "",
            getString(R.string.save), getString(R.string.reset), getString(R.string.cancel),
            onSave = { v ->
                prefs.edit().putString("cfg_url", v).apply()
                loadRemote(true)
            },
            onReset = {
                prefs.edit().remove("cfg_url").remove("remote_cache").apply()
                cfg = ConfigLoader.fromAssets(this)
                buildServers()
                updateHeaderActions()
                refreshStatuses()
                loadBackground()
            }
        )
    }

    private fun versionName(): String = try {
        "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "")
    } catch (e: Exception) {
        ""
    }

    private fun row(title: String, value: String?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
            if (onClick != null) setOnClickListener { onClick() }
        }
        r.addView(tv(title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        if (value != null) r.addView(tv(value, 13f, C_YELLOW))
        return r
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = cardBg()
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
        }
        r.addView(tv(title, 14f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(ui.toggle(checked, onChange))
        return r
    }

    // ------------------------------------------------------------ login: Google / Discord / Guest (like the reference)
    private fun authOn(): Boolean = cfg.authApiUrl.isNotBlank()

    private fun loggedIn(): Boolean =
        player.isNotBlank() && (!authOn() || !prefs.getString("token", "").isNullOrBlank())

    private fun wireLogin() {
        findViewById<View>(R.id.btnGoogle).setOnClickListener { loginGoogle() }
        findViewById<View>(R.id.btnDiscord).setOnClickListener { loginDiscord() }
        findViewById<View>(R.id.btnGuest).setOnClickListener { loginGuest() }
    }

    private fun showLogin() {
        setLoginBusy(false)
        loginMsg("")
        stack.clear()
        show(R.id.login)
    }

    private fun setLoginBusy(busy: Boolean) {
        findViewById<View>(R.id.loginProgress).visibility = if (busy) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnGoogle).isEnabled = !busy
        findViewById<View>(R.id.btnDiscord).isEnabled = !busy
        findViewById<View>(R.id.btnGuest).isEnabled = !busy
    }

    private fun loginMsg(text: String) {
        findViewById<TextView>(R.id.tvLoginMsg).text = text
    }

    private fun loginGoogle() {
        val id = googleId()
        if (id.isBlank()) {
            loginMsg(getString(R.string.login_not_configured, "Google"))
            return
        }
        loginMsg("")
        setLoginBusy(true)
        GoogleSignIn.start(
            this, id,
            { acc -> completeLogin("google", nickFrom(acc.name, acc.email), JSONObject().put("idToken", acc.idToken)) },
            { err ->
                setLoginBusy(false)
                loginMsg(getString(R.string.login_provider_failed, err))
            }
        )
    }

    private fun loginDiscord() {
        val id = discordId()
        if (id.isBlank()) {
            loginMsg(getString(R.string.login_not_configured, "Discord"))
            return
        }
        loginMsg("")
        val state = java.util.UUID.randomUUID().toString().replace("-", "")
        prefs.edit().putString("oauth_state", state).apply()
        val uri = Uri.Builder().scheme("https").authority("discord.com").path("/oauth2/authorize")
            .appendQueryParameter("client_id", id)
            .appendQueryParameter("response_type", "token")
            .appendQueryParameter("redirect_uri", "voidxen://auth")
            .appendQueryParameter("scope", "identify")
            .appendQueryParameter("state", state)
            .build()
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            loginMsg(getString(R.string.msg_no_app))
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOAuthReturn(intent)
    }

    // Discord redirects to voidxen://auth#access_token=...&state=...
    private fun handleOAuthReturn(i: Intent?) {
        val data = i?.data ?: return
        if (data.scheme != "voidxen" || data.host != "auth") return
        val frag = Uri.parse("x://y?" + (data.fragment ?: ""))
        val token = frag.getQueryParameter("access_token") ?: ""
        val state = frag.getQueryParameter("state") ?: ""
        if (token.isBlank() || state != (prefs.getString("oauth_state", "") ?: "")) {
            loginMsg(getString(R.string.login_provider_failed, "Discord"))
            return
        }
        prefs.edit().remove("oauth_state").apply()
        setLoginBusy(true)
        Thread {
            try {
                val (did, name) = Auth.discordProfile(token)
                val nick = nickFrom(name, "")
                runOnUiThread {
                    completeLogin("discord", nick, JSONObject().put("accessToken", token).put("discordId", did))
                }
            } catch (e: Exception) {
                runOnUiThread {
                    setLoginBusy(false)
                    loginMsg(getString(R.string.login_provider_failed, e.message ?: "Discord"))
                }
            }
        }.start()
    }

    private fun loginGuest() {
        var gid = prefs.getString("guest_id", "") ?: ""
        if (gid.isBlank()) {
            gid = java.util.UUID.randomUUID().toString().replace("-", "").take(6)
            prefs.edit().putString("guest_id", gid).apply()
        }
        loginMsg("")
        setLoginBusy(true)
        completeLogin("guest", "Guest_$gid", JSONObject().put("guestId", gid))
    }

    // Backend (authApiUrl) set hai to wahi identity verify karke session token deta hai; warna client-side profile.
    private fun completeLogin(provider: String, nick: String, payload: JSONObject) {
        if (!authOn()) {
            finishLogin(nick, "", "")
            return
        }
        if (!cfg.authApiUrl.startsWith("https://")) {
            setLoginBusy(false)
            loginMsg(getString(R.string.login_err_https))
            return
        }
        payload.put("action", provider).put("nickname", nick)
        val url = cfg.authApiUrl
        Thread {
            val res = try {
                Auth.post(url, payload)
            } catch (e: Exception) {
                Auth.Result(false, "", "", "", e.message ?: "Network error")
            }
            runOnUiThread {
                setLoginBusy(false)
                if (res.ok && res.token.isNotBlank()) {
                    finishLogin(res.nickname.ifBlank { nick }, res.token, res.balance)
                } else {
                    loginMsg(res.error.ifBlank { getString(R.string.login_failed) })
                }
            }
        }.start()
    }

    private fun finishLogin(nick: String, token: String, bal: String) {
        player = nick
        prefs.edit().putString("player", nick).putString("token", token).apply()
        if (bal.isNotBlank()) {
            balance = bal
            balanceViews.forEach { it.text = bal }
        }
        setLoginBusy(false)
        refreshPlayer()
        fetchProfile()
        stack.clear()
        show(R.id.home)
    }

    private fun logout() {
        prefs.edit().remove("token").remove("player").apply()
        player = ""
        balance = "—"
        balanceViews.forEach { it.text = balance }
        refreshPlayer()
        showLogin()
    }

    private fun nickFrom(name: String, email: String): String {
        var n = name.trim().replace(Regex("\\s+"), "_").replace(Regex("[^A-Za-z0-9_]"), "")
        if (n.length < 3) n = email.substringBefore('@').replace(Regex("[^A-Za-z0-9_]"), "")
        if (n.length < 3) n = "Player" + (1000 + java.util.Random().nextInt(9000))
        return n.take(24)
    }

    // ------------------------------------------------------------ HD background (sharp city for home/login, blurred for the rest)
    private val kenBurns = ArrayList<ObjectAnimator>()

    private fun startKenBurns() {
        kenBurns.clear()
        for (id in listOf(R.id.bgSharp, R.id.bgBlur)) {
            val v = findViewById<View>(id)
            for (prop in listOf(View.SCALE_X, View.SCALE_Y)) {
                val a = ObjectAnimator.ofFloat(v, prop, 1f, 1.07f)
                a.duration = 20000L
                a.repeatCount = ValueAnimator.INFINITE
                a.repeatMode = ValueAnimator.REVERSE
                a.interpolator = LinearInterpolator()
                a.start()
                kenBurns.add(a)
            }
        }
    }

    // Background: bundled original art, ya config ke backgroundUrl (Dropbox) wali apni image
    private fun loadBackground() {
        val url = backgroundUrl()
        if (url.isBlank()) {
            findViewById<ImageView>(R.id.bgSharp).setImageResource(R.drawable.bg_sharp)
            val blur = findViewById<ImageView>(R.id.bgBlur)
            blur.setImageResource(R.drawable.bg_blur)
            blur.clearColorFilter()
            return
        }
        Thread {
            val f = File(filesDir, "bg.jpg")
            try {
                if (!f.exists() || prefs.getString("bg_url", "") != url) {
                    val c = Net.open(url)
                    val bytes = try {
                        if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
                        c.inputStream.use { it.readBytes() }
                    } finally {
                        c.disconnect()
                    }
                    if (bytes.size > 15000000) throw java.io.IOException("Image too large")
                    f.writeBytes(bytes)
                    prefs.edit().putString("bg_url", url).apply()
                }
                val bmp = decodeBackground(f)
                if (bmp != null) runOnUiThread { applyBackgroundBitmap(bmp) }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun decodeBackground(f: File): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 3000) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeFile(f.absolutePath, opts)
    }

    private fun applyBackgroundBitmap(src: Bitmap) {
        findViewById<ImageView>(R.id.bgSharp).setImageBitmap(src)
        val w = (src.width / 24).coerceAtLeast(16)
        val h = (src.height / 24).coerceAtLeast(16)
        val tiny = Bitmap.createScaledBitmap(src, w, h, true)
        val blur = findViewById<ImageView>(R.id.bgBlur)
        blur.setImageBitmap(tiny)
        blur.setColorFilter(0x6E3B1771, PorterDuff.Mode.SRC_ATOP)
    }

    private fun applyBackground(id: Int) {
        val sharp = id == R.id.home || id == R.id.login
        findViewById<View>(R.id.bgSharp).animate().alpha(if (sharp) 1f else 0f).setDuration(450).start()
        findViewById<View>(R.id.bgShade).animate().alpha(if (sharp) 0.12f else 0.28f).setDuration(450).start()
    }

    // ------------------------------------------------------------ connect flow (like the reference):
    // "Checking for game updates..." -> "CONNECTING TO THE GAME" (messages change) -> game, or one clean error screen
    private enum class Act { NONE, DOWNLOAD, UPDATE, INSTALL, LOGIN }
    private class Local(val failTitle: Int, val act: Act, val downloading: Boolean)

    private var connectServer: ServerCfg? = null
    private var connectAct = Act.NONE
    private var connectGen = 0
    private val stageMsgs = intArrayOf(
        R.string.stage_msg_1, R.string.stage_msg_2, R.string.stage_msg_3, R.string.stage_msg_4, R.string.stage_msg_5
    )
    private var stageIdx = 0
    private val stageTicker = object : Runnable {
        override fun run() {
            findViewById<TextView>(R.id.tvStageSub).setText(stageMsgs[stageIdx % stageMsgs.size])
            stageIdx++
            handler.postDelayed(this, 1100L)
        }
    }

    private fun wireConnect() {
        findViewById<View>(R.id.btnRetry).setOnClickListener { connectServer?.let { runConnect(it) } }
        findViewById<View>(R.id.btnClose).setOnClickListener { goBack() }
        findViewById<View>(R.id.btnAction).setOnClickListener { onConnectAction() }
    }

    private fun onConnectAction() {
        val s = connectServer
        when (connectAct) {
            Act.DOWNLOAD, Act.UPDATE -> {
                if (s != null) {
                    startDownload(s)
                    runConnect(s)
                }
            }
            Act.INSTALL -> {
                if (s != null) installApk(s)
            }
            Act.LOGIN -> showLogin()
            Act.NONE -> { }
        }
    }

    // stage 1 = checking updates, 2 = connecting, 3 = result screen
    private fun showStage(stage: Int) {
        val loading = findViewById<View>(R.id.connectLoading)
        val result = findViewById<View>(R.id.connectResult)
        handler.removeCallbacks(stageTicker)
        if (stage == 3) {
            loading.visibility = View.GONE
            result.visibility = View.VISIBLE
            return
        }
        result.visibility = View.GONE
        loading.visibility = View.VISIBLE
        val two = stage == 2
        findViewById<View>(R.id.ivStageLogo).visibility = if (two) View.VISIBLE else View.GONE
        findViewById<View>(R.id.tvStageTitle).visibility = if (two) View.VISIBLE else View.GONE
        findViewById<View>(R.id.spinTop).visibility = if (two) View.GONE else View.VISIBLE
        findViewById<View>(R.id.spinBottom).visibility = if (two) View.VISIBLE else View.GONE
        if (two) {
            stageIdx = 0
            handler.post(stageTicker)
        } else {
            findViewById<TextView>(R.id.tvStageSub).setText(R.string.stage_checking)
        }
    }

    private fun startConnect(s: ServerCfg) {
        connectServer = s
        show(R.id.connect)
        runConnect(s)
    }

    private fun evaluateLocal(s: ServerCfg): Local {
        val st = stateOf(s)
        val installed = s.gamePackage.isNotBlank() && isInstalled(s.gamePackage)
        val downloading = running.containsKey(s.name)
        var title = 0
        var act = Act.NONE
        if (!loggedIn()) {
            title = R.string.res_title_login
            act = Act.LOGIN
        } else if (downloading) {
            title = 0
        } else if (s.downloadUrl.isBlank() && s.gamePackage.isBlank()) {
            title = R.string.res_title_files
        } else if (st == St.UPDATE) {
            title = R.string.res_title_update
            act = Act.UPDATE
        } else if (installed) {
            title = 0
        } else if (st == St.INSTALL) {
            title = R.string.res_title_install
            act = Act.INSTALL
        } else if (st == St.DOWNLOAD) {
            title = R.string.res_title_download
            act = Act.DOWNLOAD
        } else {
            title = R.string.res_title_files
        }
        return Local(title, act, downloading)
    }

    private fun runConnect(s: ServerCfg) {
        val gen = ++connectGen
        connectAct = Act.NONE
        val local = evaluateLocal(s)
        if (local.downloading) {
            showResult(R.string.res_downloading, "", true)
            return
        }
        showStage(1)
        handler.postDelayed({
            if (gen != connectGen) return@postDelayed
            showStage(2)
            val t2 = SystemClock.elapsedRealtime()
            Thread {
                val noAddr = s.ip.isBlank() || s.port <= 0
                val status = if (noAddr) null else StatusRepo.fetch(s)
                val wait = (3400L - (SystemClock.elapsedRealtime() - t2)).coerceAtLeast(0L)
                runOnUiThread {
                    if (!noAddr) {
                        statuses[s.name] = status
                        holders[s.name]?.let { updateCard(it) }
                        updateTotal()
                    }
                    handler.postDelayed({
                        if (gen == connectGen) conclude(s, local, noAddr)
                    }, wait)
                }
            }.start()
        }, 1700L)
    }

    private fun conclude(s: ServerCfg, l: Local, noAddr: Boolean) {
        var title = l.failTitle
        var act = l.act
        if (title == 0 && noAddr) {
            title = R.string.res_title_server
            act = Act.NONE
        }
        connectAct = act
        if (title != 0) {
            showResult(title, "", false)
            return
        }
        handler.removeCallbacks(stageTicker)
        findViewById<TextView>(R.id.tvStageSub).setText(R.string.stage_launching)
        val err = tryLaunch(s)
        if (err == null) {
            val gen = connectGen
            handler.postDelayed({
                if (gen == connectGen && stack.lastOrNull() == R.id.connect) goBack()
            }, 1500L)
        } else {
            connectAct = Act.NONE
            showResult(R.string.res_title_files, err, false)
        }
    }

    private fun showResult(titleRes: Int, sub: String, downloading: Boolean) {
        findViewById<TextView>(R.id.tvResultTitle).setText(titleRes)
        val subView = findViewById<TextView>(R.id.tvResultSub)
        subView.text = sub
        subView.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        findViewById<View>(R.id.connectProgressBox).visibility = if (downloading) View.VISIBLE else View.GONE
        findViewById<View>(R.id.btnRetry).visibility = if (downloading) View.GONE else View.VISIBLE
        val btn = findViewById<TextView>(R.id.btnAction)
        val label = when (connectAct) {
            Act.DOWNLOAD -> R.string.btn_download
            Act.UPDATE -> R.string.btn_update
            Act.INSTALL -> R.string.btn_install
            Act.LOGIN -> R.string.login_btn
            Act.NONE -> 0
        }
        if (label != 0) {
            btn.setText(label)
            btn.visibility = View.VISIBLE
        } else {
            btn.visibility = View.GONE
        }
        showStage(3)
    }

    // Game ko nickname, auth token, server ip/port, graphics aur language intent extras me milte hain.
    private fun tryLaunch(s: ServerCfg): String? {
        val i = packageManager.getLaunchIntentForPackage(s.gamePackage) ?: return getString(R.string.msg_game_missing)
        i.putExtra("nickname", player)
        i.putExtra("auth_token", prefs.getString("token", ""))
        i.putExtra("server_name", s.name)
        i.putExtra("server_ip", s.ip)
        i.putExtra("server_port", s.port)
        i.putExtra("graphics_quality", prefs.getString("graphics", "medium"))
        i.putExtra("fps_limit", prefs.getString("fps_limit", "60"))
        i.putExtra("language", resources.configuration.locales[0].toLanguageTag())
        i.putExtra("data_dir", GameManager.dataDir(this, s).absolutePath)
        return try {
            startActivity(i)
            null
        } catch (e: Exception) {
            e.message ?: "error"
        }
    }

    private fun onConnectProgress(s: ServerCfg, done: Long, total: Long) {
        if (connectServer?.name != s.name || stack.lastOrNull() != R.id.connect) return
        val bar = findViewById<ProgressBar>(R.id.connectProgress)
        val pct = findViewById<TextView>(R.id.connectPct)
        if (total > 0) {
            bar.isIndeterminate = false
            bar.progress = (done * 100 / total).toInt()
            pct.text = "${done * 100 / total}%"
        } else {
            bar.isIndeterminate = true
            pct.text = ""
        }
    }

    private fun onConnectDone(s: ServerCfg) {
        if (connectServer?.name == s.name && stack.lastOrNull() == R.id.connect) runConnect(s)
    }

    // ------------------------------------------------------------ navigation
    private fun show(id: Int, push: Boolean = true) {
        val target = screens.getValue(id)
        applyBackground(id)
        screens.values.forEach { if (it !== target) it.visibility = View.GONE }
        target.alpha = 0f
        target.visibility = View.VISIBLE
        target.animate().alpha(1f).setDuration(250).start()
        if (push) stack.addLast(id)
    }

    private fun goBack() {
        if (stack.isEmpty()) return
        if (stack.lastOrNull() == R.id.connect) connectGen++
        if (stack.size > 1) {
            stack.removeLast()
            show(stack.last(), push = false)
        } else finish()
    }

    // ------------------------------------------------------------ helpers
    private fun openUrl(url: String) {
        val value = url.trim()
        if (value.isBlank()) {
            toast(R.string.msg_no_url)
            return
        }
        val uri = try { Uri.parse(value) } catch (e: Exception) {
            toast(R.string.msg_no_url)
            return
        }
        if (uri.scheme != "https" && uri.scheme != "http") {
            toast(R.string.msg_no_url)
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).addCategory(Intent.CATEGORY_BROWSABLE)
            startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: ActivityNotFoundException) {
            toast(R.string.msg_no_app)
        } catch (e: Exception) {
            toast(R.string.msg_no_app)
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    private fun onWifi(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun cardBg() = GradientDrawable().apply {
        setColor(C_CARD)
        setStroke(dp(1), C_STROKE)
        cornerRadius = dp(6).toFloat()
    }

    private fun pill(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(3).toFloat()
    }

    private fun chip(t: String): TextView = tv(t, 10f, Color.WHITE).apply {
        background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), C_DIM)
            cornerRadius = dp(3).toFloat()
        }
        setPadding(dp(6), dp(1), dp(6), dp(1))
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(@StringRes id: Int, vararg args: Any) = ui.toast(getString(id, *args))
}
