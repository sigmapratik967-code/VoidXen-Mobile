package com.voidxen.launcher

import android.content.Context
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class ServerCfg(
    val name: String,
    val first: String,
    val second: String,
    val ip: String,
    val port: Int,
    val color: Int?,
    val x2: Boolean,
    val downloadUrl: String,
    val downloadFile: String,
    val sha256: String,
    val version: String,
    val statusUrl: String,
    val gamePackage: String
)

data class NewsItem(val title: String, val text: String, val date: String)

data class AppConfig(
    val supportUrl: String,
    val rulesUrl: String,
    val newsUrl: String,
    val profileApiUrl: String,
    val remoteConfigUrl: String,
    val authApiUrl: String,
    val googleClientId: String,
    val discordClientId: String,
    val backgroundUrl: String,
    val servers: List<ServerCfg>,
    val news: List<NewsItem>
)

/**
 * Central config: assets/launcher_config.json (bundled) + optional remote JSON (Dropbox).
 * Remote JSON ya to { "servers": [...], "supportUrl": ... } object ho sakta hai,
 * ya seedha server entries ka array [ {...}, {...} ].
 */
object ConfigLoader {

    fun fromAssets(ctx: Context): AppConfig {
        val text = ctx.assets.open("launcher_config.json").bufferedReader().use { it.readText() }
        return parse(text, AppConfig("", "", "", "", "", "", "", "", "", emptyList(), emptyList()))
    }

    fun parse(raw: String, base: AppConfig): AppConfig {
        val t = raw.trim().removePrefix("\uFEFF")
        val root: JSONObject
        val arr: JSONArray?
        if (t.startsWith("[")) {
            root = JSONObject()
            arr = JSONArray(t)
        } else {
            root = JSONObject(t)
            arr = root.optJSONArray("servers")
        }
        fun str(k: String, d: String): String = if (root.has(k)) root.optString(k, d).trim() else d

        val servers = if (arr != null && arr.length() > 0) {
            (0 until arr.length()).map { server(arr.getJSONObject(it), it) }
        } else base.servers
        val newsArr = root.optJSONArray("news")
        val news = if (newsArr != null) parseNews(newsArr) else base.news

        return AppConfig(
            supportUrl = str("supportUrl", base.supportUrl),
            rulesUrl = str("rulesUrl", base.rulesUrl),
            newsUrl = str("newsUrl", base.newsUrl),
            profileApiUrl = str("profileApiUrl", base.profileApiUrl),
            remoteConfigUrl = str("remoteConfigUrl", base.remoteConfigUrl),
            authApiUrl = str("authApiUrl", base.authApiUrl),
            googleClientId = str("googleClientId", base.googleClientId),
            discordClientId = str("discordClientId", base.discordClientId),
            backgroundUrl = str("backgroundUrl", base.backgroundUrl),
            servers = servers,
            news = news
        )
    }

    fun parseNews(arr: JSONArray): List<NewsItem> = (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        NewsItem(o.optString("title", ""), o.optString("text", ""), o.optString("date", ""))
    }

    private fun server(o: JSONObject, i: Int): ServerCfg {
        fun s(k: String): String = o.optString(k, "").trim()
        val name = s("name").ifBlank { "%03d".format(i + 1) }
        return ServerCfg(
            name = name,
            first = s("firstname").ifBlank { name },
            second = s("secondname"),
            ip = s("ip"),
            port = s("port").toIntOrNull() ?: 0,
            color = parseColor(s("color")),
            x2 = s("x2").equals("true", ignoreCase = true),
            downloadUrl = s("downloadUrl"),
            downloadFile = File(s("downloadFile")).name,
            sha256 = s("sha256"),
            version = s("version").ifBlank { "1" },
            statusUrl = s("statusUrl"),
            gamePackage = s("gamePackage")
        )
    }

    private fun parseColor(raw: String): Int? {
        val t = raw.trim().removePrefix("#")
        if (t.length != 6 || t.all { it == '0' }) return null
        return try { Color.parseColor("#$t") } catch (e: Exception) { null }
    }
}
